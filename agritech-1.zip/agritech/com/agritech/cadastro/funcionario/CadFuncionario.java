package com.agritech.cadastro.funcionario;
public class CadFuncionario {
    public CadFuncionario() {
        System.out.println("Criou um Funcionario");
    }   
}
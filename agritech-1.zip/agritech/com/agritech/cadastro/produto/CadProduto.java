package com.agritech.cadastro.produto;
public class CadProduto {
    public CadProduto() {
        System.out.println("Criou um Produto");
    }   
}
 
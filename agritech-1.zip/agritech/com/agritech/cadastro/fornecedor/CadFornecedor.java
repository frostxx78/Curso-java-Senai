package com.agritech.cadastro.fornecedor;
public class CadFornecedor {
    public CadFornecedor() {
        System.out.println("Criou um Fornecedor");
    }   
}
 
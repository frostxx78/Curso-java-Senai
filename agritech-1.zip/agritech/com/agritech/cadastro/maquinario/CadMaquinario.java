package com.agritech.cadastro.maquinario;
public class CadMaquinario {
    public CadMaquinario() {
        System.out.println("Criou um Maquinario");
    }   
}